#include <iostream>
#include "metEx03.h"
using namespace std;

int main() {
    metEx03 obj;
    obj.lerIdade();
}

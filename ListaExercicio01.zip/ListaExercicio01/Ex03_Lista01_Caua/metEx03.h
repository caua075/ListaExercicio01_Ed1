//
// Created by Buiu on 18/08/2022.
//

#ifndef EX03_LISTA01_CAUA_METEX03_H
#define EX03_LISTA01_CAUA_METEX03_H


class metEx03 {
public:
    void lerIdade();
    int calIdade(int ano, int mes, int dia);
};


#endif //EX03_LISTA01_CAUA_METEX03_H

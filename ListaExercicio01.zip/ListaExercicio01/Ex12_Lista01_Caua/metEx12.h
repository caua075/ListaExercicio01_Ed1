//
// Created by Buiu on 19/08/2022.
//

#ifndef EX12_LISTA01_CAUA_METEX12_H
#define EX12_LISTA01_CAUA_METEX12_H


class metEx12 {
public:
    int id;

    void lerIdade();
};


#endif //EX12_LISTA01_CAUA_METEX12_H

#include <iostream>
#include "metEx12.h"

using namespace std;

int main() {
    metEx12 obj;
    obj.lerIdade();
}

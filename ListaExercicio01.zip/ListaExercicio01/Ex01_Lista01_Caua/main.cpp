#include "metEx01.h"

using namespace std;
int main() {
    metEx01 obj;
    obj.lerPonto();
}

//
// Created by Buiu on 17/08/2022.
//

#ifndef EX01_METEX01_H
#define EX01_METEX01_H

class metEx01 {
public:
    void lerPonto();
    float calcPonto(float x1, float x2, float y1, float y2;);
};

#endif //EX01_METEX01_H

#include <iostream>
#include "metEx20.h"

using namespace std;

int main() {
    metEx20 obj;
    obj.vendas();
}

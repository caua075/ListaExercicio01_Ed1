//
// Created by Buiu on 18/08/2022.
//

#ifndef EX20_LISTA01_CAUA_METEX20_H
#define EX20_LISTA01_CAUA_METEX20_H


class metEx20 {
public:
    void vendas();
    float calcVendas(int cod, int qtd);
};


#endif //EX20_LISTA01_CAUA_METEX20_H

//
// Created by Buiu on 18/08/2022.
//

#ifndef EX05_LISTA01_CAUA_METEX05_H
#define EX05_LISTA01_CAUA_METEX05_H


class metEx05 {
public:
    void lerNotas();
    float calcNotas(float n1, float n2, float n3);
};


#endif //EX05_LISTA01_CAUA_METEX05_H

#include <iostream>
#include "metEx05.h"
using namespace std;

int main() {
    metEx05 obj;
    obj.lerNotas();
}

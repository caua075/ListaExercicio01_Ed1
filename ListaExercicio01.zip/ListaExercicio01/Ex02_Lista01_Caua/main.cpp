#include <iostream>
#include "metEx02.h"

using namespace std;

int main() {
    metEx02 obj;
    obj.lerNumeros();
}

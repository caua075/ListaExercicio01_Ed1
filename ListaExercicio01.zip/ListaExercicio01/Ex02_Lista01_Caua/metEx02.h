//
// Created by Buiu on 18/08/2022.
//

#ifndef EX02_LISTA01_CAUA_METEX02_H
#define EX02_LISTA01_CAUA_METEX02_H


class metEx02 {
public:
    void lerNumeros();
    float calcNumero(float n1, float n2, float n3);
};


#endif //EX02_LISTA01_CAUA_METEX02_H

//
// Created by Buiu on 19/08/2022.
//

#ifndef EX14_LISTA01_CAUA_METEX14_H
#define EX14_LISTA01_CAUA_METEX14_H


class metEx14 {
public:
    int cod;

    void lerNota();
    float calcMedia(float n1, float n2, float n3);
};


#endif //EX14_LISTA01_CAUA_METEX14_H

#include <iostream>
#include "metEx14.h"

using namespace std;
int main() {
    metEx14 obj;
    obj.lerNota();
}

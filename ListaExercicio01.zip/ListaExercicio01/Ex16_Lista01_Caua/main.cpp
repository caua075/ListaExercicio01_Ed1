#include <iostream>
#include "metEx16.h"

using namespace std;
int main() {
    metEx16 obj;
    obj.lerPedido();
}

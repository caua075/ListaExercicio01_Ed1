//
// Created by Buiu on 22/08/2022.
//

#ifndef EX16_LISTA01_CAUA_METEX16_H
#define EX16_LISTA01_CAUA_METEX16_H


class metEx16 {
public:
    void lerPedido();
    float calcPedido(int qtd, int cod);
};


#endif //EX16_LISTA01_CAUA_METEX16_H

//
// Created by Buiu on 19/08/2022.
//

#ifndef EX15_LISTA01_CAUA_METEX15_H
#define EX15_LISTA01_CAUA_METEX15_H


class metEx15 {
public:
    void lerNum();
};


#endif //EX15_LISTA01_CAUA_METEX15_H

#include <iostream>
#include "metEx15.h"

using namespace std;
int main() {
    metEx15 obj;
    obj.lerNum();
}

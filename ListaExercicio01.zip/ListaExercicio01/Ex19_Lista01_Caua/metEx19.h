//
// Created by Buiu on 22/08/2022.
//

#ifndef EX19_LISTA01_CAUA_METEX19_H
#define EX19_LISTA01_CAUA_METEX19_H


class metEx19 {
public:
    int cod;

    void lerNotas();
    float calcMedia(float n1, float n2, float n3);
};


#endif //EX19_LISTA01_CAUA_METEX19_H

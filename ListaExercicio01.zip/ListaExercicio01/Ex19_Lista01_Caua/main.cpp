#include <iostream>
#include "metEx19.h"

using namespace std;
int main() {
    metEx19 obj;
    obj.lerNotas();
}

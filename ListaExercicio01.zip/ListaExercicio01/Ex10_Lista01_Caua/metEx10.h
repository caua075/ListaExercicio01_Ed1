//
// Created by Buiu on 18/08/2022.
//

#ifndef EX10_LISTA01_CAUA_METEX10_H
#define EX10_LISTA01_CAUA_METEX10_H


class metEx10 {
public:
    void lerNum();
    int mostrarMaior(int n1, int n2, int n3);
};


#endif //EX10_LISTA01_CAUA_METEX10_H

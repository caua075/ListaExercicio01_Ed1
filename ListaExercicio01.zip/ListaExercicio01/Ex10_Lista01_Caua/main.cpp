#include <iostream>
#include "metEx10.h"

using namespace std;
int main() {
    metEx10 obj;
    obj.lerNum();
}

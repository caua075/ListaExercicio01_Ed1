//
// Created by Buiu on 22/08/2022.
//

#ifndef EX13_LISTA01_CAUA_METEX13_H
#define EX13_LISTA01_CAUA_METEX13_H


class metEx13 {
public:
    void mostrarMaior();
};


#endif //EX13_LISTA01_CAUA_METEX13_H

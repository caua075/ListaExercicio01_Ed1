#include <iostream>
#include "metEx13.h"

using namespace std;

int main() {
    metEx13 obj;
    obj.mostrarMaior();
}

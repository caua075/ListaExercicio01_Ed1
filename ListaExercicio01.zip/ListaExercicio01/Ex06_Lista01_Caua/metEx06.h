//
// Created by Buiu on 18/08/2022.
//

#ifndef EX06_LISTA01_CAUA_METEX06_H
#define EX06_LISTA01_CAUA_METEX06_H


class metEx06 {
public:
    void lerTempo();
    int calcHora(int seg);
    int calcMin(int seg);
};


#endif //EX06_LISTA01_CAUA_METEX06_H

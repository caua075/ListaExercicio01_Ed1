#include <iostream>
#include "metEx06.h"

using namespace std;

int main() {
    metEx06 obj;
    obj.lerTempo();
}

//
// Created by Buiu on 18/08/2022.
//

#ifndef EX07_LISTA01_CAUA_METEX07_H
#define EX07_LISTA01_CAUA_METEX07_H


class metEx07 {
public:
    void lerDado();
    float calcPreco(float custo);
};


#endif //EX07_LISTA01_CAUA_METEX07_H

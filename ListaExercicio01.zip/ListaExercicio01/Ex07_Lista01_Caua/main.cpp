#include <iostream>
#include "metEx07.h"
using namespace std;

int main() {
    metEx07 obj;
    obj.lerDado();
}

//
// Created by Buiu on 22/08/2022.
//

#ifndef EX18_LISTA01_CAUA_METEX18_H
#define EX18_LISTA01_CAUA_METEX18_H


class metEx18 {
public:
    void lerSaldo();
    float calcSaldo(float saldo);
};


#endif //EX18_LISTA01_CAUA_METEX18_H

#include <iostream>
#include "metEx18.h"

using namespace std;
int main() {
    metEx18 obj;
    obj.lerSaldo();
}

#include <iostream>
#include "metEx17.h"

using namespace std;
int main() {
    metEx17 obj;
    obj.lerDados();
}

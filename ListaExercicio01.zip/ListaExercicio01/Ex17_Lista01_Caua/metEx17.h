//
// Created by Buiu on 20/08/2022.
//

#ifndef EX17_LISTA01_CAUA_METEX17_H
#define EX17_LISTA01_CAUA_METEX17_H


class metEx17 {
public:
    char tipo;

    void lerDados();
    float calcPeso(float p, float alt);
};


#endif //EX17_LISTA01_CAUA_METEX17_H

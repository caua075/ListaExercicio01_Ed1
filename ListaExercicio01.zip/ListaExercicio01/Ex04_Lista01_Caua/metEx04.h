//
// Created by Buiu on 18/08/2022.
//

#ifndef EX04_LISTA01_CAUA_METEX04_H
#define EX04_LISTA01_CAUA_METEX04_H


class metEx04 {
public:
    void lerIdade();
    int calcAno(int dia);
    int calcMes(int dia);
    int calcDia(int dia);
};


#endif //EX04_LISTA01_CAUA_METEX04_H

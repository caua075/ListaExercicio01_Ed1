#include <iostream>
#include "metEx04.h"

int main() {
    metEx04 obj;
    obj.lerIdade();
}

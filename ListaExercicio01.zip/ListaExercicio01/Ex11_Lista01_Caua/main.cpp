#include <iostream>
#include "metEx11.h"
using namespace std;
int main() {
    metEx11 obj;
    obj.lerNum();
}

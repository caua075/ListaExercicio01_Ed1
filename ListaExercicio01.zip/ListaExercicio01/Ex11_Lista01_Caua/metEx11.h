//
// Created by Buiu on 19/08/2022.
//

#ifndef EX11_LISTA01_CAUA_METEX11_H
#define EX11_LISTA01_CAUA_METEX11_H


class metEx11 {
public:
    void lerNum();
};


#endif //EX11_LISTA01_CAUA_METEX11_H

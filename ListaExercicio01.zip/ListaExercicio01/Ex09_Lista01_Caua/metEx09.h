//
// Created by Buiu on 18/08/2022.
//

#ifndef EX09_LISTA01_CAUA_METEX09_H
#define EX09_LISTA01_CAUA_METEX09_H


class metEx09 {
public:
    float n1, n2, n3;

    void lerNota();
    float calcMedia();
};


#endif //EX09_LISTA01_CAUA_METEX09_H

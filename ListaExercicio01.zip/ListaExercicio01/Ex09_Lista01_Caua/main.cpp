#include <iostream>
#include "metEx09.h"
using namespace std;
int main() {
    metEx09 obj;
    obj.lerNota();
}
